
    const heading = document.querySelector("#heading");

const keyframes ={
    opacity:[0,1],
    //시작할때는 가로방향이 0,세로 방향은 50px 아래로 내려가도록 지정
    //끝날 때는 0으로 설정하여 가로와 세로방향으로 모두 원래의 위치로 되돌린다.
    translate : ['0 50px',0]
}
//움직임 상세(타이밍)지정
const options ={
    duration: 2000,//재생 시간을 2초로 지정
    //애니메이션이 변화하는 속도와 타이밍을 
    //ease(시작할 때와 끝날 때 느리게 변화)
    easing:'ease'
}
//움직이게 하려는 요소.animate(움직이는 내용 (키프레임),재생시간(타이밍))
heading.animate(keyframes,options);