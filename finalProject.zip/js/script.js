const loadingarea = document.querySelector('#loading');
const loadingtext = document.querySelector('#loading p');
const loadingscreen = document.querySelector('#loading-screen');
window.addEventListener("load", () => {
    loadingarea.animate({
        //backdropfilter:배경화면에 나타나는 요소를 흐리게 표현
        backdropfilter:['blur(10px)','blur(0)'],
        //opacity로 배경색에 투명도를 설정하면 backdropfilter가 제대로 동작하지 않으므로
        //배경색에 rba를 사용하여 투명한 상태에서 불투명하게 변하도록 했음.
        background:['rgba(211,211,211,1)','rgba(211,211,211,0)'],
        visibility:'hidden'
    },
    {
        duration:2000,
        delay:1200,
        easing:'ease',
        fill:'forwards'//재생후에 마지막 키프레임 상태 유지
    }
);
loadingtext.animate([
    {
        opacity:1,
        offset: .8
    }
    ,
    {
        opacity:0,
        offset:1
    }
]
,
    {
        duration:1200,
        easing:'ease',
        fill:'forwards'
  }
);
});
