const loadingAreaLeft = document.querySelector('#loading-left');
const loadingAreaRight = document.querySelector('#loading-right');
const keyframes ={
    //scaleX:x축을 따라 수평방향으로 요소의 크기를 조절하는 것
    transform:['scaleX(1)','scaleX(0)']
};
const options = {
    duration:4000,
    easing:'ease',
    fill:'forwards'
}
window.addEventListener('load',()=>{
    loadingAreaLeft.animate(keyframes,options),
    loadingAreaRight.animate(keyframes,options)
})